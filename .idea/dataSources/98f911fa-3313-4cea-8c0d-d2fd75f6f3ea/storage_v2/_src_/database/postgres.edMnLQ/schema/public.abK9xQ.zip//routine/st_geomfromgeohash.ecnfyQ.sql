create function st_geomfromgeohash(text, integer DEFAULT NULL::integer) returns geometry
    immutable
    parallel safe
    cost 1000
    language sql
as
$$
SELECT CAST(public.ST_Box2dFromGeoHash($1, $2) AS geometry);
$$;

alter function st_geomfromgeohash(text, integer) owner to postgres;

