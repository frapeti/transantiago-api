create view pg_shadow (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) as
SELECT pg_authid.rolname        AS usename,
       pg_authid.oid            AS usesysid,
       pg_authid.rolcreatedb    AS usecreatedb,
       pg_authid.rolsuper       AS usesuper,
       pg_authid.rolreplication AS userepl,
       pg_authid.rolbypassrls   AS usebypassrls,
       pg_authid.rolpassword    AS passwd,
       pg_authid.rolvaliduntil  AS valuntil,
       s.setconfig              AS useconfig
FROM pg_authid
         LEFT JOIN pg_db_role_setting s ON pg_authid.oid = s.setrole AND s.setdatabase = 0::oid
WHERE pg_authid.rolcanlogin;

alter table pg_shadow
    owner to cloudsqladmin;

